package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.myapplication.data.Employee

@Composable
fun EmployeeRow(
    employee: Employee,
    onNameChange: (String) -> Unit,
    onTimeInChange: (String) -> Unit,
    onTimeOutChange: (String) -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        OutlinedTextField(
            value = employee.name,
            onValueChange = onNameChange,
            label = { Text("Trabalhador") },
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        OutlinedTextField(
            value = employee.timeIn,
            onValueChange = onTimeInChange,
            label = { Text("Entrada") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(0.5f)
        )
        Spacer(Modifier.width(8.dp))
        OutlinedTextField(
            value = employee.timeOut,
            onValueChange = onTimeOutChange,
            label = { Text("Saída") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(0.5f)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = employee.totalHours,
            modifier = Modifier.weight(0.5f)
        )
        IconButton(onClick = onRemove) {
            Icon(Icons.Default.Delete, contentDescription = "Remover Trabalhador")
        }
    }
}


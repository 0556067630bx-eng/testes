package com.example.myapplication.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DropdownMenu(
    onCopyToTomorrow: () -> Unit,
    onCopyToWeek: () -> Unit,
    onCopyFromYesterday: () -> Unit,
    onCopyFromMonday: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.wrapContentSize(Alignment.TopEnd)) {
        Button(
            onClick = { expanded = true },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF84B9CC)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            Icon(Icons.Default.Share, contentDescription = "Transferir", tint = Color.White)
        }

        androidx.compose.material3.DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color.White)
        ) {
            DropdownMenuItem(text = "Copiar para amanhã") { onCopyToTomorrow(); expanded = false }
            DropdownMenuItem(text = "Copiar para toda semana (seg-sex)") { onCopyToWeek(); expanded = false }
            DropdownMenuItem(text = "Copiar de ontem") { onCopyFromYesterday(); expanded = false }
            DropdownMenuItem(text = "Copiar da segunda-feira") { onCopyFromMonday(); expanded = false }
        }
    }
}

@Composable
fun DropdownMenuItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(12.dp),
        color = Color.Black,
        fontSize = 14.sp
    )
}

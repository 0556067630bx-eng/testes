package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DateNavigation(
    currentDate: String,
    onPreviousDayClick: () -> Unit,
    onNextDayClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onPreviousDayClick,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4a5056)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            // Substituir por um ícone de seta real, por enquanto um texto simples
            Icon(Icons.Default.ArrowBack, contentDescription = "Dia Anterior", tint = Color.White)

        }

        Text(
            text = currentDate,
            fontFamily = FontFamily.Monospace, // isocpeur não disponível, usando Monospace
            fontSize = 18.sp,
            color = Color(0xFF444242)
        )

        Button(
            onClick = onNextDayClick,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4a5056)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            // Substituir por um ícone de seta real, por enquanto um texto simples
            Icon(Icons.Default.ArrowForward, contentDescription = "Próximo Dia", tint = Color.White)

        }
    }
}


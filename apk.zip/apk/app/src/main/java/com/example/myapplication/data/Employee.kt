package com.example.myapplication.data

data class Employee(
    val id: String = java.util.UUID.randomUUID().toString(),
    var name: String = "",
    var timeIn: String = "",
    var timeOut: String = "",
    var totalHours: String = ""
)


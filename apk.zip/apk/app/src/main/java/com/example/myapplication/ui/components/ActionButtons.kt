package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ActionButtons(
    onImportData: () -> Unit,
    onExportData: () -> Unit,
    onSaveData: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = onImportData,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF484F57)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            // Substituir por ícone de importação real
            Icon(Icons.Filled.CloudDownload, contentDescription = "Importar Dados", tint = Color(0xFF80bfff))
        }
        Spacer(Modifier.width(15.dp))
        Button(
            onClick = onExportData,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF484F57)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            // Substituir por ícone de exportação real
            Icon(Icons.Filled.CloudUpload, contentDescription = "Exportar Dados", tint = Color(0xFF80bfff))
        }
        Spacer(Modifier.width(15.dp))
        Button(
            onClick = onSaveData,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF484F57)),
            modifier = Modifier.size(48.dp) // Tamanho fixo para botões estáticos
        ) {
            Icon(Icons.Default.Save, contentDescription = "Salvar", tint = Color(0xFF80bfff))
        }
    }
}


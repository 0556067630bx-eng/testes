package com.example.myapplication.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

@Entity(tableName = "dias")
@TypeConverters(EmployeeListConverter::class)
data class DayData(
    @PrimaryKey
    val date: String, // Formato "YYYY-MM-DD"
    var employees: List<Employee>,
    var dailyNotes: String
)

class EmployeeListConverter {
    @TypeConverter
    fun fromEmployeeList(employeeList: List<Employee>): String {
        return Gson().toJson(employeeList)
    }

    @TypeConverter
    fun toEmployeeList(employeeListString: String): List<Employee> {
        val type = object : TypeToken<List<Employee>>() {}.type
        return Gson().fromJson(employeeListString, type)
    }
}


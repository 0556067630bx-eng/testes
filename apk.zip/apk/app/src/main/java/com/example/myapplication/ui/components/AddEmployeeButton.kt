package com.example.myapplication.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun AddEmployeeButton(
    onAddEmployee: () -> Unit
) {
    Button(
        onClick = onAddEmployee,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2979ff))
    ) {
        Icon(Icons.Default.Add, contentDescription = "Adicionar Trabalhador", tint = Color.White)
        Text("Adicionar Trabalhador", color = Color.White, modifier = Modifier.padding(start = 8.dp))
    }
}


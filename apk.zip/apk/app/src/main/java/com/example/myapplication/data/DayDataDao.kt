package com.example.myapplication.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DayDataDao {
    @Query("SELECT * FROM dias WHERE date = :date")
    fun getDayData(date: String): Flow<DayData?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDayData(dayData: DayData)

    @Query("DELETE FROM dias")
    suspend fun clearAllData()

    @Query("SELECT * FROM dias")
    suspend fun getAllDayData(): List<DayData>
}

